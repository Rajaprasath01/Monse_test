//
//  IAPController.swift
//  monse
//
//  Created by Victor Falcon on 24/10/22.
//

import StoreKit
import Foundation
import SwiftUI

class IAPController: ObservableObject {
    var products: [Product] = []
    
    func fetchProducts() async -> [Product] {
        do {
                let productIdentifiers = ["monse_monthly", "monse_yearly"]
                self.products = try await Product.products(for: productIdentifiers)
                print("PRODUCTS", self.products)
        } catch {
            print("PRODUCTS", error)
        }
        
        return self.products
    }
    
    func purchase(id: String) async  {
        guard let product = products.first(where: {$0.id == id}) else {return}
        
        do {
            let result = try await product.purchase()
            print("PRODUCTS", result)
            
            switch result {
            case .success(let verification):
                switch verification {
                case .verified(let transaction):
                    dispatchPurchase(transaction: transaction, verified: true, reason: "")
                    break
                    
                case .unverified(let transaction, let reason):
                    dispatchPurchase(transaction: transaction, verified: false, reason: reason.failureReason)
                    break
                }
                break
                
            case .userCancelled:
                    dispatchJsEvent(name: "purchase_status", json: "{detail: {'status': 'cancelled', 'reason': 'user_cancelled'}}")
                
            case .pending:
                    dispatchJsEvent(name: "purchase_status", json: "{detail: {'status': 'pending'}}")
            }

        } catch {
            print("PRODUCTS", error)
        }
    }
}


func dispatchPurchase(transaction: StoreKit.Transaction, verified: Bool, reason: String?) {
    let verifiedString = verified ? "true" : "false"
    let reason = reason ?? ""
    let endsAt = transaction.expirationDate?.ISO8601Format() ?? ""
    
    dispatchJsEvent(
        name: "purchase_status",
        json: "{detail: {'status': 'purchased', 'verified': \(verifiedString), 'original_transaction_id': '\(transaction.originalID)', 'product_id': '\(transaction.productID)', 'reason': '\(reason)', 'ends_at': '\(endsAt)'}}"
    )
}
