import WebKit

struct Cookie {
    var name: String
    var value: String
}

let gcmMessageIDKey = "13995305649" // update this with actual ID if using Firebase

// URL for first launch
let rootUrl = URL(string: "https://monse.app/?source=pwa")!
// let rootUrl = URL(string: "http://localhost/?source=pwa")!

// allowed origin is for what we are sticking to pwa domain
// This should also appear in Info.plist
let allowedOrigin = "monse.app"

// auth origins will open in modal and show toolbar for back into the main origin.
// These should also appear in Info.plist
let authOrigins: [String] = ["monse.app"]

let platformCookie = Cookie(name: "app-platform", value: "iOS App Store")

let displayMode = "standalone" //standalone / fullscreen

let statusBarColor = "#ffffff"
let statusBarColorDark = "#111827"
let statusBarStyle = UIStatusBarStyle.darkContent
let statusBarStyleDark = UIStatusBarStyle.lightContent
